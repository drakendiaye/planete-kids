export ECOM_ROOT=$HOME/Documents/Cours/DESS_GI/ecom
export ANT_HOME="/usr/share/ant"
export JONAS_ROOT=$ECOM_ROOT/JONAS_5_0_M1
export PATH=$PATH:$JONAS_ROOT/bin/unix
export CLASSPATH=$CLASSPATH:$JONAS_ROOT/examples/classes:$JONAS_ROOT/ECOM/classes