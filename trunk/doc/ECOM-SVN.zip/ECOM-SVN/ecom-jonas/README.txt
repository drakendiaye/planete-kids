----------------------------------------------------------------------------------
--	PROJET ECOM 								--
--      Informations sur le contenu du repertoire ECOM				--
-- 	Fabienne Boyer, Didier Donsez						--
-- 	Universite Joseph Fourier, June 2006					--
----------------------------------------------------------------------------------

 

- classes: classes des beans g�n�r�es par JOnAS


- etc: fichiers XML et HTML


- src: sources des beans (EJB3) de l'application ECOM 


- fichier build.xml :
	commandes de compilation et de d�ploiement complet (contexte Web)
	G�n�ration des fichiers : ecom.jar et ecom.war
	Copie du fichier ecom.jar dans %JONAS_ROOT%/ejb3s
	
	
	
