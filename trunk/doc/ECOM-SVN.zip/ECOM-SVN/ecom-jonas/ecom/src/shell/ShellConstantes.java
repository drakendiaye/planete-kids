/**
* eCommerce Application Sample for J2EE Training 
* @author Fabienne Boyer - july 2000
* @author Didier Donsez - november 2002  
*/

package shell;

interface ShellConstantes {
	final static String PROMPT="PROMPT";
	final static String BANNER="BANNER";
}
