/**
* eCommerce Application Sample for J2EE Training 
* Remote interface for the EcomCustomer bean
* EJB3.0 
* @author Fabienne Boyer - Didier Donsez - may 2006
*/

package ecom.beans;

public interface EcomCustomerRemote {
  // to be completed
}
