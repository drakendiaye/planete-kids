/**
* eCommerce Application Sample for J2EE Training 
* Implementation of ProductStoreBean
* @author Fabienne Boyer - Didier Donsez
* may 2006
*/

package ecom.beans;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
public class ProductStoreBean implements java.io.Serializable{

  // to be completed
}
