/**
* eCommerce Application Sample for J2EE Training 
* Local interface definition for the Cart bean
* EJB3.0 
* @author Fabienne Boyer - Didier Donsez - may 2006
*/

package ecom.beans;

public interface CartLocal {

 // to be completed
}
