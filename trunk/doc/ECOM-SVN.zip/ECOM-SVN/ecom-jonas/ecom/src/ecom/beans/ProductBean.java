/**
* eCommerce Application Sample for J2EE Training 
* Implementation of ProductBean
* @author Fabienne Boyer - Didier Donsez
* may 2006
*/

package ecom.beans;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
public class ProductBean implements java.io.Serializable{

  // to be completed
}
