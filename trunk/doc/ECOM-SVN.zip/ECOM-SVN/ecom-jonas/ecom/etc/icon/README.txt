Put your icons in the directory

Free and open-source icons can be found at
* http://www.freeiconsweb.com/
* http://www.iconarchive.com/
* http://www.vistaicons.com/

If you use icons, check the license !!!

