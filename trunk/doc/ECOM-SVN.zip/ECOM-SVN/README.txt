﻿----
==eCOM Project==
----

Wiki: http://ecom.objectweb.org/
Forge: https://forge.objectweb.org/projects/ecom/


Project information
-------------------
The following information helps the college in determining the purpose, intentions and scope of the project: 
Description of the project and its goals: 
The eCOM project is a pedagogical project to teach/learn Java enterprise technologies and related ones. The objectives are more precisely to design and develop a distributed  e-commerce application allowing many  products provided by several shops to be bought online. Java enterprise technologies are used to implement this application, such as distributed components technologies (EJB), naming services (JNDI), access to relational databases (JDBC), monitoring services (JMX), etc. The project instigates the use of Java enterprise design patterns, such as MVC/Struts, JTO, etc. It is supposed to be assumed by groups composed of four persons, which integrates an important project management feature. 
The OW2 JOnAS project is used as the main JEE technology support. 

Community
---------
This project shares the effort to maintain a open-source tutorial between several University teachers.

Current supporting team
-----------------------
* University teachers
** University Grenoble 1 (France)
** Institut National Polytechnique de Grenoble (France)
** University of Lille (France)
** University of Hammam-Sousse (Tunisia)
** ...


Competitors
-----------
SUN provides a complete J2EE tutorial[http://java.sun.com/javaee/5/docs/tutorial/doc/]  and a sample named PetStore [http://java.sun.com/developer/releases/petstore/]).
However, this tutorial is quite complex and involves only Java technologies.
IBM donated to Geronimo a set of examples such as DayTrader [http://publib.boulder.ibm.com/wasce/V1.0.1/en/Concepts/Samples.html]

Targeted audience
-----------------
Students and professional engineers who want to learn and practice Java enterprise technologies.

Roadmap
-------
The first version of the eCOM project is documented in French. The current version focuses mainly JEE technologies such as EJB3, JSP/Servlet/TagLib, JSF/Struts, AJAX. However, we target several translations with priority to English. Source code is already commented in English.
Short term
* transfer the current french documentation in the XWiki syntax in the french sub-part of the wiki
Mid term
* translate the Wiki to english, chinese, spanish, portuguese ...
* add extensions to other technologies (.NET, Hibernate, Spring, PHP, LDAP, JMS, WebServices, RESTFul Web Services JMX, CLIF, Jasmine, Google Toolkit, J2ME/MIDP/CLDC ...)

TRANSLATORS ARE WELCOME


----
Last modification: $Date: 2007-08-22 13:51:15 +0200 (mer., 22 août 2007) $ ($Rev: 4 $) by $Author: donsez $